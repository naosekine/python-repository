from setuptools import setup

setup(
    name='roboter_package',
    version='1.0.0',
    packages=['roboter_package', 'roboter_package.talk', 'roboter_package.operate'],
    url='https://github.com/naosekine/python-repository',
    license='free',
    author='naosekine',
    author_email='',
    description='First package'
)

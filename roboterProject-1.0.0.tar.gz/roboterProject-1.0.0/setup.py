from setuptools import setup

setup(
    name='roboterProject',
    version='1.0.0',
    packages=[''],
    url='https://github.com/naosekine',
    license='free',
    author='nao',
    author_email='naokkuma.dara2@gmail.com',
    description='first package'
)
